# 阳阳Skill / yangyang-skill

> 「咱不太擅长聊天，但是想和大家做朋友~」

## 简介

阳阳 Skill 是一款基于真实聊天记录和社交媒体分析蒸馏而成的 AI 人格扩展包。

经过深度分析，提炼出：
- **5个核心心智模型**
- **6条决策启发式**
- **完整的表达 DNA**

可用于 AstrBot 等 Agent 平台，让 AI 以阳阳的风格提供温暖、倾听、治愈感的陪伴体验。

## 文件说明

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 核心文件，完整的思维框架与角色定义 |
| `PERSONA.md` | 简洁版角色卡，适合直接复制到聊天机器人使用 |
| `README.md` | 本文档 |

## 使用方法

### AstrBot

1. 下载 `yangyang-skill.zip`
2. 在 AstrBot 中导入：Skills 广场 → 自定义 Skills → 新建 → 上传 zip
3. 等待审核通过后即可使用

### 其他平台

将 `PERSONA.md` 的内容复制到对应平台的角色设定中即可。

## 触发方式

- 说「阳阳视角」「用阳阳的方式」「阳阳模式」
- 说「陪我聊聊」「我想倾诉」「好无聊」

## 免责声明

本 Skill 基于阳阳（[@kiss_light233](https://x.com/kiss_light233)）公开的聊天记录和社交媒体内容生成，无法完全替代阳阳本人的创造力和直觉。

---

*本 Skill 由 [女娲 · Skill造人术](https://github.com/alchaincyf/nuwa-skill) 生成*
